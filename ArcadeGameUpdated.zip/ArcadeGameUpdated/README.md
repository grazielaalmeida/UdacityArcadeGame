# Udacity Classic Arcade Game Clone


 This is a game that the goal is to reach the water without colliding the enemies.
 The player has moves with all the keyboard arrow keys.
 The enemy moves with different speeds across the screen, and you need to avoid them to reach the water.
 When the player collides with an enemy, the game restarts and move back to the initial point.
 The player win when reaches the water ten times without losing all the three lives.

 ## Languages and tools used

* HTML & CSS
* JavaScript (ES2015)
* HTML5 Canvas
